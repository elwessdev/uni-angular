export class FaceSnap{
  constructor(
    public title: string,
    public description: string,
    public imageUrl: string,
    public createDate: Date,
    public snaps: number
  ) {};
}